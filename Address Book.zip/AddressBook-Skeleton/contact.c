#include "contact.h"

void listContacts(AddressBook *addressBook) 
{
    printf("................................................\n");
    printf("Name\t\tMobile\t\temail\n");
    printf("................................................\n");
    for(int i=0;i<addressBook->contactCount;i++){
        printf("%s\t%s\t%s\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
    }

}



void initialize(AddressBook *addressBook) 
{
    
    
}

int validphone(const char *phone) {
    if (strlen(phone) != 10) return 0;
    for (int i = 0; i < 10; i++) {
        if (phone[i] < '0' || phone[i] > '9') 
            return 0;
    }
    return 1;
}

int validemail(const char *email) {
    const char *suffix = "@gmail.com";
    size_t len = strlen(email);
    size_t suf_len = strlen(suffix);
    return len > suf_len && strcmp(email + len - suf_len, suffix) == 0;
}

void createContact(AddressBook *addressBook) {
    Contact *c = &addressBook->contacts[addressBook->contactCount];

    printf("Enter name: ");
    scanf(" %[^\n]", c->name);
    while (1) {
        printf("Enter phone number:");
        scanf(" %[^\n]", c->phone);
        getchar();
        if (!validphone(c->phone))
            printf("Invalid phone number. Please enter exactly 10 numeric digits.\n");
        else
            break;
    }

    while (1) {
        printf("Enter email: ");
        scanf(" %[^\n]", c->email);
        if (!validemail(c->email))
            printf("Invalid email. It must end with @gmail.com.\n");
        else
            break;
    }

    addressBook->contactCount++;
    printf("Contact added successfully!\n");
}

void searchContact(AddressBook *addressBook) 
{
    int choice;
    char str[100];
    int found=0;
    printf("\nSearch by:\n1.Name\n2.Phone\n3.Email\nEnter choice(1-3):");;
    scanf("%d",&choice);
    switch(choice){
        case 1:
        printf("Enter name of the contact to search: ");
        scanf(" %[^\n]", str);   

        for (int i = 0; i < addressBook->contactCount; i++)
        {
            if (strcmp(str, addressBook->contacts[i].name) == 0)
            {
                found=1;
            }
            if(found){
                printf("\nContact found!\n");
                printf("Name  : %s\n", addressBook->contacts[i].name);
                printf("Phone : %s\n", addressBook->contacts[i].phone);
                printf("Email : %s\n", addressBook->contacts[i].email);
                break;
            }
        }
        break;
        case 2:
        printf("Enter Phone number of the contact to search: ");
        scanf(" %[^\n]", str);   

        for (int i = 0; i < addressBook->contactCount; i++)
        {
            if (strcmp(str, addressBook->contacts[i].phone) == 0)
            {
                found=1;
            }
            if(found){
                printf("\nContact found!\n");
                printf("Name  : %s\n", addressBook->contacts[i].name);
                printf("Phone : %s\n", addressBook->contacts[i].phone);
                printf("Email : %s\n", addressBook->contacts[i].email);
                break;
            }
        }
        break;
        case 3:
        printf("Enter mailid of the contact to search: ");
        scanf(" %[^\n]", str);   

        for (int i = 0; i < addressBook->contactCount; i++)
        {
            if (strcmp(str, addressBook->contacts[i].email) == 0)
            {
                found=1;
            }
            if(found){
                printf("\nContact found!\n");
                printf("Name  : %s\n", addressBook->contacts[i].name);
                printf("Phone : %s\n", addressBook->contacts[i].phone);
                printf("Email : %s\n", addressBook->contacts[i].email);
                break;
            }
        }
        break;
        default:
        printf("Invalid choice select between 1-3");
    }
    if (!found)
    {
        printf("\nContact not found.\n");
    }
    
    }
void editContact(AddressBook *addressBook) {
    int choice;
    char oldvalue[100], newvalue[100];
    int found = 0;

    printf("Edit by:\n");
    printf("1. Name\n2. Phone number\n3. Email\nEnter choice (1-3): ");
    if (scanf("%d", &choice) != 1) {
        printf("Invalid input.\n");
        return;
    }
    printf("Enter the existing value to find: ");
    scanf(" %[^\n]", oldvalue); 
    for (int i = 0; i < addressBook->contactCount; i++) {
        Contact *c = &addressBook->contacts[i];
        int match = 0;

        if (choice == 1 && strcmp(c->name, oldvalue) == 0)  
            match = 1;
        else if (choice == 2 && strcmp(c->phone, oldvalue) == 0) 
            match = 1;
        else if (choice == 3 && strcmp(c->email, oldvalue) == 0) 
            match = 1;
        else if (choice < 1 || choice > 3) {
            printf("Invalid choice select btween 1-3\n");
            return;
        }

        if (match) {
            found = 1;
            switch (choice) {
                case 1:
                    printf("Enter new name: ");
                    break;
                case 2:
                    printf("Enter new phone number: ");
                    break;
                case 3:
                    printf("Enter new email: ");
                    break;
            }
            scanf(" %[^\n]", newvalue);
            if (choice == 1) {
                strncpy(c->name, newvalue, sizeof(c->name) - 1);
                c->name[sizeof(c->name) - 1] = '\0';
            } else if (choice == 2) {
                strncpy(c->phone, newvalue, sizeof(c->phone) - 1);
                c->phone[sizeof(c->phone) - 1] = '\0';
            } else {
                strncpy(c->email, newvalue, sizeof(c->email) - 1);
                c->email[sizeof(c->email) - 1] = '\0';
            }

            printf("Contact updated successfully!\n");
            break;
        }
    }

    if (!found) {
        if (choice == 1)
            printf("Name not found.\n");
        else if (choice == 2) 
            printf("Phone number not found.\n");
        else if (choice == 3) 
            printf("Email not found.\n");
    }
}
void deleteContact(AddressBook *addressBook) 
 {
    int choice;
    char str[100];
    int found = 0;

    printf("Delete by:\n");
    printf("1. Name\n2. Phone number\n3. Email\nEnter choice (1-3): ");
    if (scanf("%d", &choice) != 1) {
        printf("Invalid input.\n");
        return;
    }
    printf("Enter the value to delete: ");
    scanf(" %[^\n]", str); 
    for (int i = 0; i < addressBook->contactCount; ++i) {
        Contact *c = &addressBook->contacts[i];
        int match = 0;

        if (choice == 1 && strcmp(c->name, str) == 0) 
            match = 1;
        else if (choice == 2 && strcmp(c->phone, str) == 0) 
            match = 1;
        else if (choice == 3 && strcmp(c->email, str) == 0) 
            match = 1;
        else if (choice < 1 || choice > 3) {
            printf("Invalid choice—please select 1, 2, or 3.\n");
            return;
        }

        if (match) {
            found = 1;
            *c = addressBook->contacts[addressBook->contactCount - 1];
            addressBook->contactCount--;
            printf("Contact deleted successfully!\n");
            break;
        }
    }

    if (!found) {
        const char *ptr = (choice == 1 ? "Name" : choice == 2 ? "Phone number" : "Email");
        printf("%s not found.\n", ptr);
    }
}

void saveContactsToCSV(AddressBook *addressBook) {
    FILE *fp = fopen("contacts.csv", "w");
    if (fp==NULL) {
        printf("Failed to open");
        return;
    }
    fprintf(fp, "Name,Phone,Email\n");
    for (int i = 0; i < addressBook->contactCount; i++) {
        Contact *c = &addressBook->contacts[i];
        fprintf(fp, "%s,%s,%s\n", c->name, c->phone, c->email);
    }
    fclose(fp);
    printf("Contacts saved to contacts.csv\n");
}


void loadContactsFromCSV(AddressBook *addressBook) {
    FILE *fp = fopen("contacts.csv", "r");
    if (fp==NULL) {
        printf("contacts.csv not found—loading dummy data.\n");
        populate_contact(addressBook);
        return;
    }

    char line[200];
    addressBook->contactCount = 0;
    fgets(line, sizeof(line), fp);
    while (fgets(line, sizeof(line), fp) && addressBook->contactCount < MAX_CONTACTS) {
        char *token = strtok(line, ",");
        if (!token) continue;
        strncpy(addressBook->contacts[addressBook->contactCount].name, token, 50);

        token = strtok(NULL, ",");
        if (!token) continue;
        strncpy(addressBook->contacts[addressBook->contactCount].phone, token, 20);

        token = strtok(NULL, "\n");
        if (!token) continue;
        strncpy(addressBook->contacts[addressBook->contactCount].email, token, 50);

        addressBook->contactCount++;
    }
    fclose(fp);
    
        
}


