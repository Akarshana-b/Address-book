#include "contact.h"

int main()
{
    int choice;
    AddressBook s1;
    initialize(&s1);
    loadContactsFromCSV(&s1);
    do{
        printf("1.Create Contact\n");
        printf("2.Edit Contact\n");
        printf("3.Search Contact\n");
        printf("4.Delete Contact\n");
        printf("5.List Contact\n");
        printf("6.save and exit\n");
        printf("Enter your choice(Between 1 and 6):\n");
        scanf("%d",&choice);
        switch(choice)
        {
            case 1:
            printf("Create contact is selected\n");
            createContact(&s1);
            break;
            case 2:
            printf("Edit contact is selected\n");
            editContact(&s1);
            break;
            case 3:
            printf("Search contact is selected\n");
            searchContact(&s1);
            break;
            case 4:
            printf("Delete contact is selected\n");
            deleteContact(&s1);
            break;
            case 5:
            printf("List contact is selected\n");
            listContacts(&s1);
            break;
            case 6:
            printf("Save and exit is selected\n");
            saveContactsToCSV(&s1);
            printf("Exiting...\n");
            break;
            default:
            printf("Inavlid input");
        }
    } while(choice!=6);
    //all function calls should be inside the main 
}

